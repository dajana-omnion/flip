 <div class="pull-right hidden-xs">
      <b>All things digital</b> 
    </div>
    <strong>Copyright &copy; 2018 <a href="http://omnion.tech" target="_blank">Omnion</a> & <a href="http://kreacija.si" target="_blank">Kreacija</a></strong> 